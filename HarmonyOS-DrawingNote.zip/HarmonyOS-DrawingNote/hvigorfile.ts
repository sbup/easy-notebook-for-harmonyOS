// 导入HspDependencyConfig
import { HspDependencyConfig } from '@ohos/hvigor-ohos-plugin';

// 声明并导出配置对象
export default {
  // 项目依赖配置
  dependencyConfig: new HspDependencyConfig(),
  // 项目描述
  description: 'Huawei DrawingNote HarmonyOS Application',
  // 项目名称
  name: 'DrawingNote',
  // 版本号
  version: '1.0.0'
};
